// DO NOT EDIT. This is code generated via package:easy_localization/generate.dart

abstract class  LocaleKeys {
  static const welcome_text = 'welcome_text';
  static const uploadtext = 'uploadtext';
  static const streamText = 'streamText';
  static const chooseText = 'chooseText';
  static const dialog_enterText = 'dialog.enterText';
  static const dialog_hintText = 'dialog.hintText';
  static const dialog_okText = 'dialog.okText';
  static const dialog_Cancel = 'dialog.Cancel';
  static const dialog_validationText = 'dialog.validationText';
  static const dialog = 'dialog';
  static const drawer_themeText = 'drawer.themeText';
  static const drawer_langText = 'drawer.langText';
  static const drawer_aboutText = 'drawer.aboutText';
  static const drawer_reportText = 'drawer.reportText';
  static const drawer = 'drawer';
  static const suggestedtext = 'suggestedtext';
  static const confirmation_selected_text = 'confirmation.selected_text';
  static const confirmation_subsuploadtext = 'confirmation.subsuploadtext';
  static const confirmation_nofiletext = 'confirmation.nofiletext';
  static const confirmation_descText = 'confirmation.descText';
  static const confirmation_betterText = 'confirmation.betterText';
  static const confirmation_FastnetText = 'confirmation.FastnetText';
  static const confirmation_subText = 'confirmation.subText';
  static const confirmation_ProcessText = 'confirmation.ProcessText';
  static const confirmation_startText = 'confirmation.startText';
  static const confirmation = 'confirmation';
  static const plottext = 'plottext';
  static const plots_batmanPlot = 'plots.batmanPlot';
  static const plots_takenPlot = 'plots.takenPlot';
  static const plots_fastPlot = 'plots.fastPlot';
  static const plots_hacksawPlot = 'plots.hacksawPlot';
  static const plots = 'plots';
  static const displayText_doneText = 'displayText.doneText';
  static const displayText_saveText = 'displayText.saveText';
  static const displayText_shareText = 'displayText.shareText';
  static const displayText_deleteText = 'displayText.deleteText';
  static const displayText_AnotherText = 'displayText.AnotherText';
  static const displayText_deleteDialog = 'displayText.deleteDialog';
  static const displayText = 'displayText';

}
